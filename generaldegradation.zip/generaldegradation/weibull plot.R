
pdf("weibull.pdf", width = 6, height = 4)  # Adjust width and height as needed

# Define the Weibull PDF
weibull_pdf <- function(x, lambda, k) {
  (k / lambda) * (x / lambda)^(k - 1) * exp(-(x / lambda)^k)
}

# Set up the plot
x <- seq(0, 4, length.out = 1000)
ymin <- 0
ymax <- 2
colors <- c("dodgerblue", "red", "plum4")

# Plot the first curve
plot(x, weibull_pdf(x, lambda = 1, k = 0.1), type = "l", col = colors[1], 
     ylim = c(ymin, ymax), xlim = c(0, 4), xlab = expression(x), 
     ylab = expression(f(x =  lambda, k)), lwd = 2)

# Add the second curve
lines(x, weibull_pdf(x, lambda = 1, k = 1), col = colors[2], lwd = 2)

# Add the third curve
lines(x, weibull_pdf(x, lambda = 1, k = 5), col = colors[3], lwd = 2)

# Add a grid
grid()

# Add a legend
legend("topright", legend = c(expression(k == 0.1), 
                              expression(k == 1), 
                              expression(k == 5)), 
       col = colors, lwd = 2, bty = "n")

dev.off()
