

pdf("explanatory plot.pdf", width = 9, height = 7)  # Adjust width and height as needed
# Main plot
par(mar = c(5, 5, 4, 2) + 0.1)  # Adjust margins to create more space
plot(NA, NA, xlim=c(0, 1800), ylim=c(0, 1), xlab="Time (years)", ylab="Absolute condition", xaxt="n", yaxt="n", bty="n", type="n")
axis(1, at=c(100, 1000), lwd=1)
axis(2, las=1, lwd=1)




# Shaded area indicating margin of error0
upper <- exp(-0.0015 * x) + 0.3 * (x / 2000)
lower <- exp(-0.0015 * x) - 0.3 * (x / 2000)

polygon(c(x, rev(x)), c(upper, rev(lower)), col="#FF9999", border=NA)  # Removed density parameter

# Exponential decay line
x <- seq(0, 2000, length.out=100)
y <- exp(-0.0015 * x)
lines(x, y, col="red", lwd=2)  # zorder to make sure it's plotted over shading


# Horizontal dotted line
abline(h=0.9, lty=2, col="black", lwd=1)

# Add text over the dashed line
text(x = 600, y = 0.92, "Operational conditon threshold", pos = 4, col = "black", cex = 1)

# Add arrow pointing right in the middle of the plot
middle_x <- 1000
middle_y <- 0.05
arrow_length <- 500  # Adjust arrow length to make it visible
arrows(middle_x - arrow_length/2, middle_y, middle_x + arrow_length/2, middle_y, length = 0.1)
text(x = 500, y = 0.09, "The uncertainty increases \n towards the end of a lifetime", pos = 4, col = "black", cex = 1)


# Add a black box around the main plot
box(lwd=2)

# Inset plot within the main plot area
par(fig=c(0.4, 0.85, 0.4, 0.85), new=TRUE)
plot(NA, NA, xlim=c(0, 100), ylim=c(0.9, 1), xlab="Time (years)", ylab="Absolute condition", xaxt="n", yaxt="n", bty="n", type="n", bg="white")  # Set bg to white
axis(1, at=c(0, 50, 100), lwd=1)
axis(2, las=1, lwd=1)



# Shaded area indicating margin of error in the inset plot
upper_inset <- 1 - 0.001 * x_inset + 0.01 * (x_inset / 100)
lower_inset <- 1 - 0.001 * x_inset - 0.01 * (x_inset / 100)
polygon(c(x_inset, rev(x_inset)), c(upper_inset, rev(lower_inset)), col="#FF9999", border=NA)  # Removed density parameter



# Linear decay line in the inset plot
x_inset <- seq(0, 100, length.out=100)
y_inset <- 1 - 0.001 * x_inset
lines(x_inset, y_inset, col="red", lwd=2)

# Add a black box around the inset plot
box(lwd=2)

par(new = TRUE)
plot(x=c(0,0),y=c(0,1), ylim = c(0,1), xlab= "" , ylab="", xaxt="n", yaxt="n", bty="n", type="n")
axis(side=4, las = 1, col =  "blue", col.axis =  "blue")
mtext("Contingent condition", side=4, line=3, col = "blue")

dev.off()
