library(truncnorm)

source("functions.R")

# Set parameters
num_agents <- 1000  # Population size
num_years <- 500   # Number of years to simulate
num_simulations <- 10 # Number of simulations

# Define degradation processes with separate mean times

degradation_processes <- list(
  # First process – serious fire where fire service is called in a single room
  list(fraction_affected = c(0.2, 0.6), condition_loss = c(100, 100), mean_time = c(200, 600)),
  
  # Second process – serious incident of heritage crime where something of high value is stolen
  list(fraction_affected = c(0.002, 0.006), condition_loss = c(100, 100), mean_time = c(5, 10)),
  
  # Third process – flood from overflowing drains that affects several rooms on the ground floor
  list(fraction_affected = c(0.02, 0.06), condition_loss = c(20, 50), mean_time = c(1, 5)),
  
  # Fourth process – a roof element will leak in heavy rain causing damage to interiors
  list(fraction_affected = c(0.02, 0.06), condition_loss = c(0, 0), mean_time = c(0.02, 0.06))
)

# Set initial conditions for all agents

lower_bound <- 0
upper_bound <- 100
mean <- 70
sd <- 20

# Set environmental conditions and continuous degradation

T = 22
RH = 50/100
pH = 7
DP0 = 3000
time_deg = time_degradation(T,RH,pH,DP0)
deg_rate = 100/time_deg

# Initial Condition: Generate random numbers from a truncated normal distribution 

agent_conditions_0 <- rtruncnorm(n = num_agents, a = lower_bound, b = upper_bound, mean = mean, sd = sd)


# Function to run the agent-based simulation for multiple years
run_simulation <- function(num_agents, num_years, degradation_processes, num_simulations) {
  # Initialize list to store conditions for each simulation
  all_conditions <- vector("list", length = num_simulations)
  all_percentage_good <- matrix(NA, nrow = num_years, ncol = num_simulations)
  
  # Iterate over each simulation
  for (sim in 1:num_simulations) {
    
    # Set initial conditions for all agents
    
    agent_conditions <- agent_conditions_0

    # Create a matrix to store agent conditions for each year
    agent_conditions_history <- matrix(NA, nrow = num_years, ncol = num_agents)
    agent_conditions_history[1, ] <- agent_conditions
    
    # Iterate over each year
    for (year in 2:num_years) {
      
      # Simulate continuous degradation
      agent_conditions <- simulate_continuous_degradation(agent_conditions, deg_rate)
      
      # Predict occurrence of adverse events for each degradation process using Weibull distribution
      for (process in degradation_processes) {
        mean_time <- runif(1, process$mean_time[1], process$mean_time[2])
        time_until_event <- rweibull(1, shape = 1, scale = mean_time)
        
        # Check if adverse event occurs
        if (time_until_event <= 1) {
          # Simulate adverse event and update agent conditions
          agent_conditions <- simulate_adverse_event(agent_conditions, list(process))
        }
      }
      
      # Store updated agent conditions for the current year
      agent_conditions_history[year, ] <- agent_conditions
      
      # Calculate percentage of objects in good condition (C > 0)
      percentage_good <- sum(agent_conditions > 0) / length(agent_conditions) * 100
      all_percentage_good[year, sim] <- percentage_good
    }
    
    # Save conditions for the current simulation
    all_conditions[[sim]] <- agent_conditions_history[num_years, ]
  }
  
  # Return the conditions for all simulations and percentage of objects in good condition
  return(list(all_conditions = all_conditions, all_percentage_good = all_percentage_good))
}

# Set seed for reproducibility
#set.seed(123)

# Run the simulation
results <- run_simulation(num_agents, num_years, degradation_processes, num_simulations)

# Obtain a list of the conditions of the last simulation for plotting
all_conditions_flat <- unlist(results$all_conditions[10])

# Exclude values that are zero or lower
all_conditions_flat_positive <- all_conditions_flat[all_conditions_flat > 0]

# Plot histogram of conditions excluding zero or lower values

pdf("hist.pdf", width = 7, height = 5)  # Adjust width and height as needed

breaks = seq(0,100,by=5)
# Create a histogram of initial agent conditions with grey color
hist(agent_conditions_0, breaks = breaks, 
     xlab = "Agent Condition", ylab = "Frequency", col = "#FF9999", xlim = c(0, 100), main = "")

# Add a histogram of final results with red color, using the same breaks
hist(all_conditions_flat_positive, breaks = breaks, add = TRUE, col = "dodgerblue", density = 30, angle = 45)

# Add legend
legend("topright", legend = c("Initial", "Final"), fill = c("#FF9999", "dodgerblue"))

dev.off()

# Plot time series of percentage of objects in good condition for each simulation run

pdf("main plot.pdf", width = 8, height = 6)  # Adjust width and height as needed

# Generate shades of red
plot_colors <- colorRampPalette(c("red", "dodgerblue"))(num_simulations)

# Plot the first simulation
plot(1:num_years, results$all_percentage_good[, 1], type = "l",
     xlab = "Time (years)", ylab = "% Objects in good condition", 
     col = plot_colors[1], ylim = c(0, 100))

# Add lines for the remaining simulations
for (sim in 2:num_simulations) {
  lines(1:num_years, results$all_percentage_good[, sim], type = "l", col = plot_colors[sim])
}

# Move the legend a bit to the center
legend("topright", inset = c(0.05, 0.01), legend = 1:num_simulations, col = plot_colors, lty = 1, 
       title = "Simulation Run", cex = 0.8, bty = "n")

dev.off()

# Calculate time to reach 1% for each simulation
time_to_1_percent <- numeric(num_simulations)
for (sim in 1:num_simulations) {
  # Find the index of the first occurrence where the percentage crosses 1%
  index_1_percent <- which(results$all_percentage_good[, sim] <= 1)[1]
  if (length(index_1_percent) > 0) {
    time_to_1_percent[sim] <- index_1_percent
  } else {
    time_to_1_percent[sim] <- NA  # Mark as NA if 1% not reached
  }
}

# Calculate average time to reach 1% and its standard deviation
average_time <- mean(time_to_1_percent, na.rm = TRUE)
sd_time <- sd(time_to_1_percent, na.rm = TRUE)



# Print results
cat("Collection lifetime (time to reach 1%):", round(average_time, 2), "\n")
cat("Standard deviation of the lifetime:", round(sd_time, 2), "\n")
if (is.na(average_time)) {
  cat("End of lifetime not reached for all simulations. Add more years. \n")
} else {
  # Find simulations that did not reach 1%
  max_time <- max(time_to_1_percent, na.rm = TRUE)
  cat("Max lifetime:", max_time, "\n")
}

