# Load necessary package
library(fmsb)

pdf("spider.pdf", width = 6, height = 6)  # Adjust width and height as needed

# Example data for two heritage objects
object1 <- c(6, 7.5, 8, 5, 6.5, 7, 8.5, 9)  # Mean values for object 1
object2 <- c(7, 8, 6.5, 7.5, 6, 5.5, 8, 7)  # Mean values for object 2

# Create data frame in the required format
data <- data.frame(
  row.names = c("Max", "Min", "Object 1", "Object 2"),
  color = c(10, 0, object1[1], object2[1]),
  strength = c(10, 0, object1[2], object2[2]),
  reflectance = c(10, 0, object1[3], object2[3]),
  recession = c(10, 0, object1[4], object2[4]),
  cracking = c(10, 0, object1[5], object2[5]),
  delamination = c(10, 0, object1[6], object2[6]),
  dissociation = c(10, 0, object1[7], object2[7]),
  shape = c(10, 0, object1[8], object2[8])
)

# Define color and transparency
colors <- c(rgb(1, 0, 0, 0.5),rgb(0.1, 0.56, 1, 0.8))

# Create radar chart
radarchart(
  data, axistype = 1,
  pcol = colors, pfcol = colors,
  plwd = 2, plty = 1, 
  cglcol = "grey", cglty = 1, cglwd = 0.8,
  axislabcol = "grey", 
  vlabels = colnames(data)[-c(1:2)], 
  vlcex = 0.8
)

# Add legend
legend(x = "topright", legend = c("Object 1", "Object 2"), bty = "n", pch = 20, col = colors, text.col = "black", cex = 0.8)

dev.off()