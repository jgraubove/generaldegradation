
# Function to solve the Strlic damage function for paper
time_degradation <- function(T,RH,pH,DP0) {
  
  A = 38.039
  B = 38.057
  C = 1.67*T-285.655
  D = 2.491-0.012*T
  E = 0.24
  F = 14713 / (T + 273.15)
  
  lnk = A + B * (log(1-RH)/C)^(1/D) + E *log(10^-pH)-F
  
  t = (1/exp(lnk))*(1/300-1/DP0)
  
  return(t)
}

simulate_continuous_degradation <- function(agent_conditions, deg_rate, return_loss = FALSE) {
  # Calculate degradation for each agent
  new_conditions <- agent_conditions - deg_rate
  
  # Clip condition to be non-negative
  new_conditions <- pmax(new_conditions, 0)
  
  # Calculate loss due to continuous degradation
  continuous_loss <- sum(agent_conditions - new_conditions)
  
  if (return_loss) {
    return(list(new_conditions, continuous_loss))
  } else {
    return(new_conditions)
  }
}


# Function to simulate adverse event and update agent conditions
simulate_adverse_event <- function(agent_conditions, degradation_processes) {
  # Initialize condition loss for each agent
  condition_loss <- rep(0, length(agent_conditions))
  
  # Iterate over each degradation process
  for (process in degradation_processes) {
    # Determine the number of agents affected by the current process
    num_agents_affected <- round(runif(1, process$fraction_affected[1], process$fraction_affected[2]) * length(agent_conditions))
    
    # Randomly select agents to be affected
    affected_agents <- sample(length(agent_conditions), size = num_agents_affected, replace = FALSE)
    
    # Update conditions of affected agents
    for (agent in affected_agents) {
      # Calculate random condition loss within the specified range for the current process
      loss <- sample(process$condition_loss[1]:process$condition_loss[2], size = 1)
      # Add the condition loss for the current process to the overall condition loss
      condition_loss[agent] <- condition_loss[agent] + loss
    }
  }
  
  # Update agent conditions by subtracting the overall condition loss
  agent_conditions <- pmax(agent_conditions - condition_loss, 0)
  
  # Return updated agent conditions
  return(agent_conditions)
}
